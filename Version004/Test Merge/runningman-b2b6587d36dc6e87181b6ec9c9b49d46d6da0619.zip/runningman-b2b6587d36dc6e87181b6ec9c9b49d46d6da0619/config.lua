ForegroundProps = {
	"cohart96.png",
	"Rock-1.png",
	"tree-1.png",
	"tree-2.png",
	"tree-3.png",
}

BackgroundProps = {
	"mountain-1.png",
	"mountain-2.png",
	"tree-1.png",
	"tree-2.png",
	"tree-3.png",
}

PropsWithPhysics = {
	"cohart96.png",
	"Rock-1.png",
}
